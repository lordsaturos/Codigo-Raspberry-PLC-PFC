To install:
    - mkdir Build
    - cd Build
    - cmake ../
    - make
    - sudo make install
