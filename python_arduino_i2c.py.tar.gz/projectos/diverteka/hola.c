#include <stdio.h>
#include "inc/gpio.h"
#include "inc/i2c.h"

int main() {
	printf("Hola Mundo desde mi RaspPi...\n");
	gpioSetup()
	gpioI2cSetup
	return 0;
}
